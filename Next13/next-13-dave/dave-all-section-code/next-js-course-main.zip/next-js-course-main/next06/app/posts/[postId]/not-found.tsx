export default function NotFound() {
    return (
        <h1>The requested post does not exist.</h1>
    )
}