type BlogPost = {
    id: string,
    title: string,
    date: string,
}