export default function NotFound() {
    return (
        <h1>The requested user does not exist.</h1>
    )
}