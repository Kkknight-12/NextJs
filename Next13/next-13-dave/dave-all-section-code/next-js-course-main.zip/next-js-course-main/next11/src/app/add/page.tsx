import AddTodo from "@/app/components/AddTodo"

export default function page() {
    return (
        <AddTodo />
    )
}